/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package opensoa.drools;

import java.io.Serializable;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Decision Request Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Serializable
 * @generated
 */
public interface DecisionRequestType extends Serializable
{
} // DecisionRequestType
