/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package opensoa.drools;

import java.io.Serializable;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Manage Service Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Serializable
 * @generated
 */
public interface ManageServiceType extends Serializable
{
} // ManageServiceType
