/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package opensoa.drools;

import java.io.Serializable;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Decision Response Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @extends Serializable
 * @generated
 */
public interface DecisionResponseType extends Serializable
{
} // DecisionResponseType
